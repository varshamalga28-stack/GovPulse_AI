from predictor import predictor
from database import save_complaint

def predict_complaint(request):

    result = predictor.predict_emergency(request.complaint)

    complaint = {
        "complaint": request.complaint,
        "customer_name": request.customer_name,
        "email": request.email,
        "phone": request.phone
    }

    save_complaint(complaint)

    return result