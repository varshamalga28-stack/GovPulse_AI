from fastapi import APIRouter
from schemas import ComplaintRequest
from services.prediction_service import predict_complaint

router = APIRouter(
    prefix="/api",
    tags=["Prediction"]
)

@router.post("/predict")
def predict(request: ComplaintRequest):
    return predict_complaint(request)

from fastapi import APIRouter
from database import get_prediction_history

router = APIRouter()


@router.get("/history")
def prediction_history():

    data = get_prediction_history()

    return {
        "total_predictions": len(data),
        "history": data
    }

from fastapi import APIRouter
from database import get_prediction_history

router = APIRouter()


@router.get("/history")
def prediction_history():

    data = get_prediction_history()

    return {
        "total_predictions": len(data),
        "history": data
    }