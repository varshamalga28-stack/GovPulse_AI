from fastapi import APIRouter
from schemas import FeedbackRequest
from database import save_feedback

router = APIRouter(
    prefix="/api",
    tags=["Feedback"]
)

@router.post("/feedback")
def submit_feedback(request: FeedbackRequest):

    data = {
        "prediction_id": request.prediction_id,
        "rating": request.rating,
        "feedback": request.feedback
    }

    save_feedback(data)

    return {
        "message": "Feedback submitted successfully"
    }

from fastapi import APIRouter
from schemas import FeedbackRequest
from database import save_feedback

router = APIRouter()

@router.post("/")
def add_feedback(request: FeedbackRequest):

    data = {
        "prediction_id": request.prediction_id,
        "rating": request.rating,
        "feedback": request.feedback
    }

    save_feedback(data)

    return {
        "message": "Feedback saved successfully"
    }